import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { getCategories } from '../../../Redux/categorySlice'
import { Link } from 'react-router-dom'
import { getLatestArticles } from '../../../Redux/latestBlogSlice'

const Sidebar = () => {
    const dispatch = useDispatch()
    const { category, status } = useSelector((state) => state.Category)
    const { latestArticles, latestArticlesStatus } = useSelector((state) => state.LatestArticles)

    useEffect(() => {
        dispatch(getCategories())
        dispatch(getLatestArticles())
    }, [])
console.log(latestArticlesStatus);
    return (
        <>
            <div class="card">
                <form class="form-inline my-2 my-lg-0">
                    <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" />
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Find</button>
                </form>
            </div>
            {/* Blog Categories */}
            <div class="card mt-3">
                <div class="card-header">
                    Categories
                </div>
                <ul class="list-group list-group-flush">
                    {
                        status === 'success' && category?.data !== null && category?.data !== undefined && category?.data !== '' ? (
                            <>
                                {
                                    category?.data.map((item, index) => {
                                        return (
                                            <>
                                                <li class="list-group-item"><Link to={`/blog/category/${item._id}`}>{item.category}</Link></li>
                                            </>
                                        )
                                    })
                                }
                            </>
                        ) : (
                            <></>
                        )
                    }
                </ul>
            </div>
            {/* Latest Articles */}
            <div class="card mt-3">
                <div class="card-header">
                    Latest Articles
                </div>
                <ul class="list-group list-group-flush">
                    {
                        latestArticlesStatus === 'success' ? (
                            <>
                                {
                                    latestArticles?.data.map((latestPost, ind) => {
                                        return (
                                            <>
                                                <li class="list-group-item"><Link to={`/article/${latestPost._id}`}>{latestPost.title}</Link></li>
                                            </>
                                        )
                                    })
                                }
                            </>
                        ) : (
                            <></>
                        )
                    }
                </ul>
            </div>
        </>
    )
}

export default Sidebar
