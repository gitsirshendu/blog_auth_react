import React from 'react'

const AboutUs = () => {
  return (
    <>
      <div className="container">
                <div className="row mt-5">
                    <div className="col-sm">
                        <h1>About Us</h1>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In efficitur elit ac blandit commodo. Donec pharetra tempor turpis tristique mattis. Duis molestie nisi in sodales fringilla. In hac habitasse platea dictumst. Phasellus non dignissim ante. Pellentesque porttitor nisi in eros vulputate finibus. Nunc at facilisis erat, condimentum dictum magna. Phasellus scelerisque, elit tempus elementum viverra, velit mi pellentesque erat, sed ultricies ligula tellus vel nibh. Aenean convallis consequat odio, sed feugiat mauris ultricies a. Suspendisse sit amet malesuada tellus. Vivamus et diam elit.</p>
                    </div>
                </div>
            </div>
    </>
  )
}

export default AboutUs
