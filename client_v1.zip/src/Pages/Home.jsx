import React from 'react'

const Home = () => {
    return (
        <>
            <div className="container">
                <div className="row mt-5">
                    <div className="col-sm">
                        <h1>Welcome to Homepage</h1>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In efficitur elit ac blandit commodo. Donec pharetra tempor turpis tristique mattis. Duis molestie nisi in sodales fringilla. In hac habitasse platea dictumst. Phasellus non dignissim ante. Pellentesque porttitor nisi in eros vulputate finibus. Nunc at facilisis erat, condimentum dictum magna. Phasellus scelerisque, elit tempus elementum viverra, velit mi pellentesque erat, sed ultricies ligula tellus vel nibh. Aenean convallis consequat odio, sed feugiat mauris ultricies a. Suspendisse sit amet malesuada tellus. Vivamus et diam elit.</p>
                        <p>Aenean pretium pulvinar augue. In porta vitae tortor sed feugiat. Curabitur efficitur urna id varius tincidunt. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Suspendisse potenti. Ut cursus, tellus vitae commodo tristique, velit ex cursus sem, in aliquet dui erat sed massa. Interdum et malesuada fames ac ante ipsum primis in faucibus. Nulla a sem gravida, rutrum urna non, pulvinar leo. Praesent ut blandit ipsum. Vivamus blandit massa eget dui varius, a consectetur dui suscipit. Duis metus enim, lacinia in hendrerit in, ornare in massa. Etiam commodo aliquam rhoncus. Aenean eget erat aliquam ante ultricies pellentesque ut non orci.</p>
                        <p>Duis et venenatis purus. Vivamus viverra mauris leo, at ultrices est tristique sit amet. Nullam consectetur viverra urna, sit amet consequat urna molestie vitae. Phasellus vel accumsan metus, quis hendrerit nibh. Nulla luctus rhoncus porttitor. Nulla a nulla ut tellus condimentum pulvinar at ac tortor. Maecenas quam tellus, pretium id ipsum in, imperdiet convallis diam. Etiam vitae sapien imperdiet, sollicitudin urna non, porta orci. Integer id euismod ipsum, sed feugiat turpis. Sed sit amet mauris sapien. Nulla ut sem ut nisi dapibus porttitor. Praesent auctor quam ac gravida scelerisque. Sed consequat, justo nec dictum imperdiet, ligula turpis blandit mauris, sit amet venenatis turpis tortor id erat. Cras molestie interdum felis, sit amet mollis nisi tincidunt eget.</p>                       
                    </div>
                </div>
            </div>
        </>
    )
}

export default Home
