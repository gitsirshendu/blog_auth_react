import { configureStore } from "@reduxjs/toolkit";
import { authSlice } from "../authSlice";
import { blogSlice } from "./blogSlice";

const Store=configureStore({
    reducer:{
        Auth: authSlice.reducer,
        Blog: blogSlice.reducer
    }
})

export default Store